package com.marketsimplified;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.marketsimplified.EmployeeDatabase;


@WebServlet("/Response1")
public class ServletDatabase extends HttpServlet 

{

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("application/json");

		StringBuffer jb = new StringBuffer();

		String line = null;

		BufferedReader reader = request.getReader();

		while ((line = reader.readLine()) != null) {
		    jb.append(line);
		}

		JSONObject jsobj = new JSONObject(jb.toString());

		int id = jsobj.getInt("id");
		int empno = jsobj.getInt("empno"); // Get the empno value

		// Use the id and empno values as needed
		// For example, you can print them or use them in your business logic

		System.out.println("id: " + id);
		System.out.println("empno: " + empno);
			
			try 
			{
				System.out.println("1st step done");
				EmployeeDatabase emp = new EmployeeDatabase();
				System.out.println("1st step done");
				String jsonData = emp.searchRecord(id,empno);
				System.out.println("2nd step done");
				response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        PrintWriter out = response.getWriter();
		        out.write(jsonData);
		        System.out.println(jsonData);
			} 
			catch (Exception e) 
			{
				
				System.out.println(e);
			}
	}
}
